# Full statistical results

This reviewer-facing archive contains complete result tables supporting the manuscript, not raw sequencing data. GSE174188 is the discovery and internal donor-nonoverlap resource; GSE135779 is the independent childhood validation dataset; GSE23307 is descriptive at two paired donors.

The original frozen gene-level, composition, transcription, regulatory, design and statistical-framework directories are retained. `identity_robustness/` adds the 20-replicate end-to-end disease-blind reconstruction audit and downstream B_CONV/B_ASC boundary-propagation results. The formal state-overlap HOLD is retained; these same-data sensitivities do not constitute independent replication.

Large raw matrices and per-cell assignment exports are intentionally excluded. All displayed S9 data are also supplied in Figure Source Data. File-level hashes are recorded in `MANIFEST_SHA256.csv`.
