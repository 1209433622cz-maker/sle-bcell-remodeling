# Current review scope

The 163 historical statistical payloads remain byte-identical. external_mapping_calibration/ adds 20 correction records; no new disease effects are present. This supplement is review-only and has no matching new DOI.
