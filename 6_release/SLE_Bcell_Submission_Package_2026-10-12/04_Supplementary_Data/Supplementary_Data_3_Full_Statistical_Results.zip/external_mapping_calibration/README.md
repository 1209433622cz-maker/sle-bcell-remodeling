# Corrected external-mapping calibration

Reference and external cells use full-library log1p(CP10K). All 56 matrices were processed, but the primary elastic-net B_ASC precision (0.885210) did not meet 0.90. No corrected disease outcome was estimated. Original C9 effects are excluded from supporting evidence. The source-label-defined primary GSE135779 replication is unchanged.

The 72 candidate rows and donor-grouped folds are reference calibration diagnostics, not independently held-out performance. Original outcomes were known before correction. Centroid success does not replace the required primary mapper.

The original 17_FILE_INTEGRITY_MANIFEST.csv records a LOCAL run, including three omitted per-cell payloads listed in LOCAL_ONLY_PAYLOADS.csv. It is provenance, not a completeness manifest for this subset. The enclosing MANIFEST_SHA256.csv is the complete attachment manifest.
